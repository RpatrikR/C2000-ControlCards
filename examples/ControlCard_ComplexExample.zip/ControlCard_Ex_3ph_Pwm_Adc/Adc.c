/*
 * Adc.c
 */
#include "Adc.h"
#include "Pwm.h"
#include "Transformations.h"

Uint16 adcAraw = 0;
Uint16 adcBraw = 0;
Uint16 adcCraw = 0;
float32 voltageA = 0.0;
float32 voltageB = 0.0;
float32 voltageC = 0.0;

float32 d_axis = 1.0;
float32 q_axis = 0.0;
tsPark invPark;
tsPark Park;
float32 anglePU;
float32 time = 0.0;
Uint16 sampleNum = 0;

tsClarke invClarke;
tsClarke Clarke;



__interrupt void Adc_A_Interrupt(void)
{
    // Reading raw values and calculating the average of two samples
    adcAraw = (AdcaResultRegs.ADCRESULT0 + AdcaResultRegs.ADCRESULT1) >> 1;
    adcBraw = (AdcbResultRegs.ADCRESULT0 + AdcbResultRegs.ADCRESULT1) >> 1;
    adcCraw = (AdccResultRegs.ADCRESULT0 + AdccResultRegs.ADCRESULT1) >> 1;

    // Conversion of raw values to voltage
    voltageA = adcAraw * ADC_CONST;
    voltageB = adcBraw * ADC_CONST;
    voltageC = adcCraw * ADC_CONST;

    // Angle emulation in per units (PU)
    anglePU = SIG_FREQ * time;
    time += TIME_STEP;
    sampleNum++;
    if(sampleNum >= SAMPLES_PER_PERIOD)
    {
        time = 0.0;
        sampleNum = 0;
    }

    // Inverse Park Transformation
    invPark.d = d_axis;
    invPark.q = q_axis;
    invPark.sine = __sinpuf32(anglePU);
    invPark.cosine = __cospuf32(anglePU);
    InvParkTrans(&invPark);

    // Inverse Clarke Transformation
    invClarke.alpha = invPark.alpha;
    invClarke.beta = invPark.beta;
    InvClarkeTrans(&invClarke);

    // Reference signals for PWMs
    EPwm1Regs.CMPA.bit.CMPA = (Uint16) ((PWM_PRD_UPDOWN_10KHZ >> 1) * (1.0 + invClarke.a));    // reference signal for phase A
    EPwm2Regs.CMPA.bit.CMPA = (Uint16) ((PWM_PRD_UPDOWN_10KHZ >> 1) * (1.0 + invClarke.b));    // reference signal for phase B
    EPwm6Regs.CMPA.bit.CMPA = (Uint16) ((PWM_PRD_UPDOWN_10KHZ >> 1) * (1.0 + invClarke.c));    // reference signal for phase C


    // Clarke Transformation - for verifying transformations
    Clarke.a = invClarke.a;
    Clarke.b = invClarke.b;
    Clarke.c = invClarke.c;
    ClarkeTrans(&Clarke);

    // Park Transformation - for verifying transformations
    Park.alpha = Clarke.alpha;
    Park.beta = Clarke.beta;
    Park.sine = __sinpuf32(anglePU);
    Park.cosine = __cospuf32(anglePU);
    ParkTrans(&Park);


    AdcaRegs.ADCINTFLGCLR.bit.ADCINT1 = 1;  // Clears ADCINT1 and ADCINT1RESULT flags in the ADCINTFLG register.
    PieCtrlRegs.PIEACK.bit.ACK1 = 1;
}



void Adc_A_Init(void)
{
    EALLOW;
    AdcaRegs.ADCCTL1.bit.ADCPWDNZ = 0;      // All analog circuitry inside the core is powered down
    AdcaRegs.ADCCTL1.bit.INTPULSEPOS = 1;   // Interrupt pulse generation occurs at the end of the conversion

    AdcSetMode(ADC_ADCA, ADC_RESOLUTION_12BIT, ADC_SIGNALMODE_SINGLE);  // Set the resolution and signalmode for a given ADC. This will
                                                                        // ensure that the correct trim is loaded.
    AdcaRegs.ADCCTL2.bit.PRESCALE = 6;      //  ADCCLK = fsysclk / 4.0 = 200MHz / 4 = 50 MHz; fadclk is max 50MHz

    AnalogSubsysRegs.ANAREFCTL.bit.ANAREFASEL = 1;  // Set external VREF

    // Adc Interrupts
    AdcaRegs.ADCINTSEL1N2.bit.INT1SEL = 1;  // EOC1 is trigger for ADCINT1
    AdcaRegs.ADCINTSEL1N2.bit.INT1E = 1;    // ADCINT1 is enabled
    AdcaRegs.ADCINTSEL1N2.bit.INT1CONT = 0; // No further ADCINT1 pulses are generated until ADCINT1 flag (in ADCINTFLG register) is cleared by user.

    // SOC0
    AdcaRegs.ADCSOC0CTL.bit.EXTCHSEL = 0;   // ADCEXTMUX = 0
    AdcaRegs.ADCSOC0CTL.bit.TRIGSEL = 5;    // ePWM1, ADCSOCA
    AdcaRegs.ADCSOC0CTL.bit.CHSEL = 1;      // ADCAIN1
    AdcaRegs.ADCSOC0CTL.bit.ACQPS = ADC_ACQPS; // Sample window (ADC_ACQPS + 1) * Tsysclk; MINIMUM SAMPLE WINDOW from DS!!!
                                            // Size of sample window depends on external electrical circuit connected to ADC pin.

    // SOC1
    AdcaRegs.ADCSOC1CTL.bit.EXTCHSEL = 0;   // ADCEXTMUX = 0
    AdcaRegs.ADCSOC1CTL.bit.TRIGSEL = 5;    // ePWM1, ADCSOCA
    AdcaRegs.ADCSOC1CTL.bit.CHSEL = 1;      // ADCAIN1
    AdcaRegs.ADCSOC1CTL.bit.ACQPS = ADC_ACQPS; // Sample window (ADC_ACQPS + 1) * Tsysclk; MINIMUM SAMPLE WINDOW from DS!!!
                                            // Size of sample window depends on external electrical circuit connected to ADC pin.

    AdcaRegs.ADCCTL1.bit.ADCPWDNZ = 1;      // All analog circuitry inside the core is powered up
    EDIS;
}


void Adc_B_Init(void)
{
    EALLOW;
    AdcbRegs.ADCCTL1.bit.ADCPWDNZ = 0;      // All analog circuitry inside the core is powered down
    AdcbRegs.ADCCTL1.bit.INTPULSEPOS = 1;   // Interrupt pulse generation occurs at the end of the conversion

    AdcSetMode(ADC_ADCB, ADC_RESOLUTION_12BIT, ADC_SIGNALMODE_SINGLE);  // Set the resolution and signalmode for a given ADC. This will
                                                                        // ensure that the correct trim is loaded.
    AdcbRegs.ADCCTL2.bit.PRESCALE = 6;      //  ADCCLK = fsysclk / 4.0 = 200MHz / 4 = 50 MHz; fadclk is max 50MHz

    AnalogSubsysRegs.ANAREFCTL.bit.ANAREFBSEL = 1;  // Set external VREF

    // Adc Interrupts
    AdcbRegs.ADCINTSEL1N2.bit.INT1SEL = 1;  // EOC1 is trigger for ADCINT1
    AdcbRegs.ADCINTSEL1N2.bit.INT1E = 0;    // ADCINT1 is disabled
    AdcbRegs.ADCINTSEL1N2.bit.INT1CONT = 0; // No further ADCINT1 pulses are generated until ADCINT1 flag (in ADCINTFLG register) is cleared by user.

    // SOC0
    AdcbRegs.ADCSOC0CTL.bit.EXTCHSEL = 0;   // ADCEXTMUX = 0
    AdcbRegs.ADCSOC0CTL.bit.TRIGSEL = 5;    // ePWM1, ADCSOCA
    AdcbRegs.ADCSOC0CTL.bit.CHSEL = 6;      // ADCBIN6
    AdcbRegs.ADCSOC0CTL.bit.ACQPS = ADC_ACQPS; // Sample window (ADC_ACQPS + 1) * Tsysclk; MINIMUM SAMPLE WINDOW from DS!!!
                                            // Size of sample window depends on external electrical circuit connected to ADC pin.

    // SOC1
    AdcbRegs.ADCSOC1CTL.bit.EXTCHSEL = 0;   // ADCEXTMUX = 0
    AdcbRegs.ADCSOC1CTL.bit.TRIGSEL = 5;    // ePWM1, ADCSOCA
    AdcbRegs.ADCSOC1CTL.bit.CHSEL = 6;      // ADCBIN6
    AdcbRegs.ADCSOC1CTL.bit.ACQPS = ADC_ACQPS; // Sample window (ADC_ACQPS + 1) * Tsysclk; MINIMUM SAMPLE WINDOW from DS!!!
                                            // Size of sample window depends on external electrical circuit connected to ADC pin.

    AdcbRegs.ADCCTL1.bit.ADCPWDNZ = 1;      // All analog circuitry inside the core is powered up
    EDIS;
}


void Adc_C_Init(void)
{
    EALLOW;
    AdccRegs.ADCCTL1.bit.ADCPWDNZ = 0;      // All analog circuitry inside the core is powered down
    AdccRegs.ADCCTL1.bit.INTPULSEPOS = 1;   // Interrupt pulse generation occurs at the end of the conversion

    AdcSetMode(ADC_ADCC, ADC_RESOLUTION_12BIT, ADC_SIGNALMODE_SINGLE);  // Set the resolution and signalmode for a given ADC. This will
                                                                        // ensure that the correct trim is loaded.
    AdccRegs.ADCCTL2.bit.PRESCALE = 6;      //  ADCCLK = fsysclk / 4.0 = 200MHz / 4 = 50 MHz; fadclk is max 50MHz

    AnalogSubsysRegs.ANAREFCTL.bit.ANAREFCSEL = 1;  // Set external VREF

    // Adc Interrupts
    AdccRegs.ADCINTSEL1N2.bit.INT1SEL = 1;  // EOC1 is trigger for ADCINT1
    AdccRegs.ADCINTSEL1N2.bit.INT1E = 0;    // ADCINT1 is disabled
    AdccRegs.ADCINTSEL1N2.bit.INT1CONT = 0; // No further ADCINT1 pulses are generated until ADCINT1 flag (in ADCINTFLG register) is cleared by user.

    // SOC0
    AdccRegs.ADCSOC0CTL.bit.EXTCHSEL = 0;   // ADCEXTMUX = 0
    AdccRegs.ADCSOC0CTL.bit.TRIGSEL = 5;    // ePWM1, ADCSOCA
    AdccRegs.ADCSOC0CTL.bit.CHSEL = 4;      // ADCCIN4
    AdccRegs.ADCSOC0CTL.bit.ACQPS = ADC_ACQPS; // Sample window (ADC_ACQPS + 1) * Tsysclk; MINIMUM SAMPLE WINDOW from DS!!!
                                            // Size of sample window depends on external electrical circuit connected to ADC pin.

    // SOC1
    AdccRegs.ADCSOC1CTL.bit.EXTCHSEL = 0;   // ADCEXTMUX = 0
    AdccRegs.ADCSOC1CTL.bit.TRIGSEL = 5;    // ePWM1, ADCSOCA
    AdccRegs.ADCSOC1CTL.bit.CHSEL = 4;      // ADCCIN4
    AdccRegs.ADCSOC1CTL.bit.ACQPS = ADC_ACQPS; // Sample window (ADC_ACQPS + 1) * Tsysclk; MINIMUM SAMPLE WINDOW from DS!!!
                                            // Size of sample window depends on external electrical circuit connected to ADC pin.

    AdccRegs.ADCCTL1.bit.ADCPWDNZ = 1;      // All analog circuitry inside the core is powered up
    EDIS;
}
