/*
 * Transformations.h
 */

#ifndef TRANSFORMATIONS_H_
#define TRANSFORMATIONS_H_


#include "f28p65x_device.h"


typedef struct {
    float32 a;
    float32 b;
    float32 c;
    float32 alpha;
    float32 beta;
} tsClarke;


typedef struct {
    float32 alpha;
    float32 beta;
    float32 d;
    float32 q;
    float32 sine;
    float32 cosine;
} tsPark;


extern void ClarkeTrans(tsClarke *v);
extern void InvClarkeTrans(tsClarke *v);
extern void ParkTrans(tsPark *v);
extern void InvParkTrans(tsPark *v);

#endif /* TRANSFORMATIONS_H_ */
