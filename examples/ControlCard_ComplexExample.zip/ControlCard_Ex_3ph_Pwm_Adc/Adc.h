/*
 * Adc.h
 *
 *      +-------------+---------+----------+
 *      | ADC Channel | MCU pin | Card pin |
 *      +-------------+---------+----------+
 *      | ADCAIN1     | 24      | 54       |
 *      | ADCBIN6     | 36      | 47       |
 *      | ADCCIN4     | 13      | 48       |
 *      +-------------+---------+----------+
 */

#ifndef ADC_H_
#define ADC_H_

#include "f28p65x_device.h"
#include "f28p65x_examples.h"

#define ADC_CONST   0.000732600733f // ADC_CONST = Vref/4095 = 3.0/4095 = 0.000732600733

// Tau = Rfilt * (Cfilt + Cp) + (Rfilt + Rsh) * Csh = 100 * (1nF + 2.7pF) + (100 + 500) * 12.5pF = 107.77 ns
// tacq = Tau * ln((2^N * Csh) / (Cfilt + Cp + Csh)) = 107.77ns * ln((2^12 * 12.5pF) / (1n + 2.7pF + 12.5pF)) = 422.53ns
// tacq = 422.53ns -> ACQPS = 42 -> Sample Window = (42 + 1) * Tsysclk = 43 * 10ns = 430ns
#define ADC_ACQPS   42U

#define SIG_FREQ   100.0f           // modulated signal frequency 100 Hz
#define SAMPLES_PER_PERIOD   100U   // number of samples per signal period; 100 samples per period
#define TIME_STEP   100.0e-6        // time step 100us

extern __interrupt void Adc_A_Interrupt(void);
extern __interrupt void Adc_B_Interrupt(void);
extern __interrupt void Adc_C_Interrupt(void);

extern void Adc_A_Init(void);
extern void Adc_B_Init(void);
extern void Adc_C_Init(void);

#endif /* ADC_H_ */
