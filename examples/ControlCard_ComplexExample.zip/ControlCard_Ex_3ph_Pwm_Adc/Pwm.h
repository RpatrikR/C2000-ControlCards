/*
 * Pwm.h
 *
 */

#ifndef PWM_H_
#define PWM_H_

#include "f28p65x_device.h"

#define PWM_PRD_UPDOWN_10KHZ 10000U     // fpwm = 10kHz @ fTBCLK = 200MHz
#define PWM_DEAD_TIME           50U     // Dead Time = 50 * Tsysclk = 50 * 5ns = 250ns @ fTBCLK = 200MHz

extern void ePwm1_Init(void);
extern void ePwm1_Start(void);
extern void ePwm1_Stop(void);

extern void ePwm2_Init(void);
extern void ePwm2_Start(void);
extern void ePwm2_Stop(void);

extern void ePwm6_Init(void);
extern void ePwm6_Start(void);
extern void ePwm6_Stop(void);

#endif /* PWM_H_ */
