/*
 * Gpio.h
 *
 */

#ifndef GPIO_H_
#define GPIO_H_

#include "f28p65x_device.h"     // Headerfile Include File
#include "f28p65x_examples.h"   // Examples Include File

#define LED1_ON    (GpioDataRegs.GPBSET.bit.GPIO34 = 1)
#define LED1_OFF   (GpioDataRegs.GPBCLEAR.bit.GPIO34 = 1)
#define LED1_TOG   (GpioDataRegs.GPBTOGGLE.bit.GPIO34 = 1)

#define LED_STS_ON     (GpioDataRegs.GPGSET.bit.GPIO200 = 1)
#define LED_STS_OFF    (GpioDataRegs.GPGCLEAR.bit.GPIO200 = 1)
#define LED_STS_TOG    (GpioDataRegs.GPGTOGGLE.bit.GPIO200 = 1)

extern void Gpio_Init(void);

#endif /* GPIO_H_ */
