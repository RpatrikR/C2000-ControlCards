/*
 * Pwm.c
 *
 */

#include "Pwm.h"

void ePwm1_Init(void)
{
   EPwm1Regs.TBCTL.bit.CLKDIV = 0;          // divider /1
   EPwm1Regs.TBCTL.bit.HSPCLKDIV = 0;       // divider /1
   EPwm1Regs.TBCTL.bit.PRDLD = 0;           // Active Period Reg Load from Shadow Select
   EPwm1Regs.EPWMSYNCOUTEN.bit.ZEROEN = 1;  // TBCTR = 0 event to set the EPWMxSYNCOUT signal

   // fpwm = 10kHz @ fsysclk = 200MHz and Up-Down mode
   EPwm1Regs.TBPRD = PWM_PRD_UPDOWN_10KHZ;
   // Duty = 20%
   EPwm1Regs.CMPA.bit.CMPA = 2000;

   EPwm1Regs.AQCTLA.bit.CAU = 1;
   EPwm1Regs.AQCTLA.bit.CAD = 2;

   // Dead Time
   EPwm1Regs.DBCTL.bit.IN_MODE = 0;             // EPWMxA In (from the action-qualifier) is the source for both falling-edge and rising-edge delay.
   EPwm1Regs.DBCTL.bit.POLSEL = 2;              // Active high complementary (AHC). EPWMxB is inverted.
   EPwm1Regs.DBCTL.bit.OUT_MODE = 3;            // DeadBand Module is fully enabled (i.e. both RED and FED active)
   EPwm1Regs.DBRED.bit.DBRED = PWM_DEAD_TIME;   // Dead-Band Generator Rising Edge Delay
   EPwm1Regs.DBFED.bit.DBFED = PWM_DEAD_TIME;   // Dead-Band Generator Falling Edge Delay

   // SOC A trigger for ADC
   EPwm1Regs.ETSEL.bit.SOCASEL = 2;             // EPWMxSOCA pulse will be generated when time-base counter equal to period (TBCTR = TBPRD)
   EPwm1Regs.ETSEL.bit.SOCAEN = 1;              // Enable EPWMxSOCA pulse.
   EPwm1Regs.ETPS.bit.SOCAPRD = 1;              // Generate the EPWMxSOCA pulse on the first event
}


void ePwm1_Start(void)
{
    EPwm1Regs.TBCTL.bit.CTRMODE = 2;    // Up-Down mode
}


void ePwm1_Stop(void)
{
    EPwm1Regs.TBCTL.bit.CTRMODE = 3;    // Freeze counter
}


void ePwm2_Init(void)
{
   EPwm2Regs.TBCTL.bit.CLKDIV = 0;      // divider /1
   EPwm2Regs.TBCTL.bit.HSPCLKDIV = 0;   // divider /1
   EPwm2Regs.TBCTL.bit.PRDLD = 0;       // Active Period Reg Load from Shadow Select
   EPwm2Regs.TBCTL.bit.PHSEN = 1;       // Enable synchronization
   EPwm2Regs.TBCTL.bit.PHSDIR = 1;      // Count up after the synchronization event

   EPwm2Regs.TBPHS.bit.TBPHS = 2;       // time-base counter (TBCTR) will be loaded with the phase (TBPHS) when a synchronization event occurs

   EPwm2Regs.EPWMSYNCINSEL.bit.SEL = 1; // ePWM1 is the source of the EPWMxSYNCI signal

   // fpwm = 10kHz @ fsysclk = 200MHz and Up-Down mode
   EPwm2Regs.TBPRD = PWM_PRD_UPDOWN_10KHZ;
   // Duty = 20%
   EPwm2Regs.CMPA.bit.CMPA = 2000;

   EPwm2Regs.AQCTLA.bit.CAU = 1;
   EPwm2Regs.AQCTLA.bit.CAD = 2;

   // Dead Time
   EPwm2Regs.DBCTL.bit.IN_MODE = 0;             // EPWMxA In (from the action-qualifier) is the source for both falling-edge and rising-edge delay.
   EPwm2Regs.DBCTL.bit.POLSEL = 2;              // Active high complementary (AHC). EPWMxB is inverted.
   EPwm2Regs.DBCTL.bit.OUT_MODE = 3;            // DeadBand Module is fully enabled (i.e. both RED and FED active)
   EPwm2Regs.DBRED.bit.DBRED = PWM_DEAD_TIME;   // Dead-Band Generator Rising Edge Delay
   EPwm2Regs.DBFED.bit.DBFED = PWM_DEAD_TIME;   // Dead-Band Generator Falling Edge Delay
}


void ePwm2_Start(void)
{
    EPwm2Regs.TBCTL.bit.CTRMODE = 2;    // Up-Down mode
}


void ePwm2_Stop(void)
{
    EPwm2Regs.TBCTL.bit.CTRMODE = 3;    // Freeze counter
}


void ePwm6_Init(void)
{
   EPwm6Regs.TBCTL.bit.CLKDIV = 0;      // divider /1
   EPwm6Regs.TBCTL.bit.HSPCLKDIV = 0;   // divider /1
   EPwm6Regs.TBCTL.bit.PRDLD = 0;       // Active Period Reg Load from Shadow Select
   EPwm6Regs.TBCTL.bit.PHSEN = 1;       // Enable synchronization
   EPwm6Regs.TBCTL.bit.PHSDIR = 1;      // Count up after the synchronization event

   EPwm6Regs.TBPHS.bit.TBPHS = 2;       // time-base counter (TBCTR) will be loaded with the phase (TBPHS) when a synchronization event occurs

   EPwm6Regs.EPWMSYNCINSEL.bit.SEL = 1; // ePWM1 is the source of the EPWMxSYNCI signal

   // fpwm = 10kHz @ fsysclk = 200MHz and Up-Down mode
   EPwm6Regs.TBPRD = PWM_PRD_UPDOWN_10KHZ;
   // Duty = 20%
   EPwm6Regs.CMPA.bit.CMPA = 2000;

   EPwm6Regs.AQCTLA.bit.CAU = 1;
   EPwm6Regs.AQCTLA.bit.CAD = 2;

   // Dead Time
   EPwm6Regs.DBCTL.bit.IN_MODE = 0;             // EPWMxA In (from the action-qualifier) is the source for both falling-edge and rising-edge delay.
   EPwm6Regs.DBCTL.bit.POLSEL = 2;              // Active high complementary (AHC). EPWMxB is inverted.
   EPwm6Regs.DBCTL.bit.OUT_MODE = 3;            // DeadBand Module is fully enabled (i.e. both RED and FED active)
   EPwm6Regs.DBRED.bit.DBRED = PWM_DEAD_TIME;   // Dead-Band Generator Rising Edge Delay
   EPwm6Regs.DBFED.bit.DBFED = PWM_DEAD_TIME;   // Dead-Band Generator Falling Edge Delay

}


void ePwm6_Start(void)
{
    EPwm6Regs.TBCTL.bit.CTRMODE = 2;    // Up-Down mode
}


void ePwm6_Stop(void)
{
    EPwm6Regs.TBCTL.bit.CTRMODE = 3;    // Freeze counter
}
