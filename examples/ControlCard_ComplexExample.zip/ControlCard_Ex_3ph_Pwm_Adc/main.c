/*
 * Sinusoidal 3-phase PWM + ADC
 */
#include "Gpio.h"
#include "CpuTimer.h"
#include "Pwm.h"
#include "Adc.h"


int main(void)
{
    InitSysCtrl();

    DINT;
    IER = 0x0000;
    IFR = 0x0000;

    EALLOW;
    PieVectTable.ADCA1_INT = &Adc_A_Interrupt;
    PieVectTable.TIMER0_INT = &CpuTimer0_Isr;
    EDIS;

    PieCtrlRegs.PIEIER1.bit.INTx1 = 1;  // ADCA1 INT
    PieCtrlRegs.PIEIER1.bit.INTx7 = 1;  // TIMER0 INT
    PieCtrlRegs.PIECTRL.bit.ENPIE = 1;  // enable PIE

    IER = M_INT1;
    EINT;


    EALLOW;
    ClkCfgRegs.PERCLKDIVSEL.bit.EPWMCLKDIV = 0;
    EDIS;

    Gpio_Init();
    CpuTimer0_Init();

    EALLOW;
    CpuSysRegs.PCLKCR0.bit.TBCLKSYNC = 0;
    EDIS;
    ePwm1_Init();
    ePwm2_Init();
    ePwm6_Init();
    EALLOW;
    CpuSysRegs.PCLKCR0.bit.TBCLKSYNC = 1;
    EDIS;
    Adc_A_Init();
    Adc_B_Init();
    Adc_C_Init();

    CpuTimer0_Start();
    ePwm1_Start();
    ePwm2_Start();
    ePwm6_Start();



    while(1)
    {
        ;
    }

	return 0;
}
