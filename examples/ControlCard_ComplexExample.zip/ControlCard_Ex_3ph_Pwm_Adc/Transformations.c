/*
 * Transformations.c
 */

#include "Transformations.h"


void ClarkeTrans(tsClarke *v)
{
    // Nesymetricka sustava
    v->alpha = 0.6666666667 * (v->a - (0.5*(v->b + v->c)));
    v->beta = 0.5773502692 * (v->b - v->c);

    /*
    // Symetricka
    v->alpha = v->a;
    v->beta = (0.5773502692 * v->a) + (1.1547005384 * v->b);
    */
}


void InvClarkeTrans(tsClarke *v)
{
    v->a = v->alpha;
    v->b = (0.8660254038 * v->beta) - (0.5 * v->alpha);
    v->c = -(0.5 * v->alpha) - (0.8660254038 * v->beta);
}


void ParkTrans(tsPark *v)
{
    // The q-axis aligns with the alpha-axis
    v->d = (v->alpha * v->sine) - (v->beta * v->cosine);
    v->q = (v->alpha * v->cosine) + (v->beta * v->sine);

    /*
    // The d-axis aligns with the alpha-axis
    v->d = (v->alpha * v->cosine) + (v->beta * v->sine);
    v->q = (v->beta * v->cosine) - (v->alpha * v->sine);
    */
}


void InvParkTrans(tsPark *v)
{
    // The q-axis aligns with the alpha-axis
    v->alpha = (v->d * v->sine) + (v->q * v->cosine);
    v->beta = (v->q * v->sine) - (v->d * v->cosine);

    /*
    // The d-axis aligns with the alpha-axis
    v->alpha = (v->d * v->cosine) - (v->q * v->sine);
    v->beta = (v->d * v->sine) + (v->q * v->cosine);
    */
}
