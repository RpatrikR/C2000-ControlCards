/*
 * Status LED blinking
 */
#include "Gpio.h"
#include "CpuTimer.h"



int main(void)
{
    InitSysCtrl();

    DINT;
    IER = 0x0000;
    IFR = 0x0000;

    EALLOW;
    PieVectTable.TIMER0_INT = &CpuTimer0_Isr;
    EDIS;

    PieCtrlRegs.PIEIER1.bit.INTx7 = 1;  // TIMER0 INT
    PieCtrlRegs.PIECTRL.bit.ENPIE = 1;  // enable PIE

    IER = M_INT1;
    EINT;


    Gpio_Init();
    CpuTimer0_Init();

    CpuTimer0_Start();


    while(1)
    {
        ;
    }

	return 0;
}
