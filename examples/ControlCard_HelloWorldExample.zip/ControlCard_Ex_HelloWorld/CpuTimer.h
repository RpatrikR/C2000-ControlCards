/*
 * CpuTimer.h
 *
 */

#ifndef CPUTIMER_H_
#define CPUTIMER_H_

#include "f28p65x_device.h"     // Headerfile Include File
#include "f28p65x_examples.h"   // Examples Include File

#include "Gpio.h"

extern __interrupt void CpuTimer0_Isr(void);

extern void CpuTimer0_Init(void);
extern void CpuTimer0_Start(void);
extern void CpuTimer0_Stop(void);

#endif /* CPUTIMER_H_ */
