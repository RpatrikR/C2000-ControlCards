/*
 * CpuTimer.c
 *
 */

#include "CpuTimer.h"


__interrupt void CpuTimer0_Isr(void)
{
    LED_STS_TOG;

    CpuTimer0Regs.TCR.bit.TIF = 1;      // clear TIF flag
    PieCtrlRegs.PIEACK.bit.ACK1 = 1;
}

void CpuTimer0_Init(void)
{
    CpuTimer0Regs.TCR.bit.TSS = 1;      // stop timer
    CpuTimer0Regs.TCR.bit.TIF = 1;      // clear TIF flag
    CpuTimer0Regs.TCR.bit.TIE = 1;      // enable interrupt
    CpuTimer0Regs.PRD.all = 99999999;   // f = 2Hz @ fsysclk = 200MHz
    CpuTimer0Regs.TCR.bit.TRB = 1;      // reload timer

}

void CpuTimer0_Start(void)
{
    CpuTimer0Regs.TCR.bit.TRB = 1;  // reload timer
    CpuTimer0Regs.TCR.bit.TSS = 0;  // start timer
}

void CpuTimer0_Stop(void)
{
    CpuTimer0Regs.TCR.bit.TSS = 1;  // stop timer
}
