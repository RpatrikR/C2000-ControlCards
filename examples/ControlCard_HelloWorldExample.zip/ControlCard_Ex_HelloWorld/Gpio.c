/*
 * Gpio.c
 *
 */

#include "Gpio.h"

void Gpio_Init(void)
{
    EALLOW;

    // Gpio0 - ePWM1A
    GpioCtrlRegs.GPAGMUX1.bit.GPIO0 = 0;
    GpioCtrlRegs.GPAMUX1.bit.GPIO0 = 1;

    // Gpio1 - ePWM1B
    GpioCtrlRegs.GPAGMUX1.bit.GPIO1 = 0;
    GpioCtrlRegs.GPAMUX1.bit.GPIO1 = 1;

    // Gpio2 - ePWM2A
    GpioCtrlRegs.GPAGMUX1.bit.GPIO2 = 0;
    GpioCtrlRegs.GPAMUX1.bit.GPIO2 = 1;

    // Gpio3 - ePWM2B
    GpioCtrlRegs.GPAGMUX1.bit.GPIO3 = 0;
    GpioCtrlRegs.GPAMUX1.bit.GPIO3 = 1;

    // Gpio4 - ePWM3A
    GpioCtrlRegs.GPAGMUX1.bit.GPIO4 = 0;
    GpioCtrlRegs.GPAMUX1.bit.GPIO4 = 1;

    // Gpio10 - ePWM6A
    GpioCtrlRegs.GPAGMUX1.bit.GPIO10 = 0;
    GpioCtrlRegs.GPAMUX1.bit.GPIO10 = 1;

    // Gpio11 - ePWM6B
    GpioCtrlRegs.GPAGMUX1.bit.GPIO11 = 0;
    GpioCtrlRegs.GPAMUX1.bit.GPIO11 = 1;

    // Gpio12 - ePWM7A
    GpioCtrlRegs.GPAGMUX1.bit.GPIO12 = 0;
    GpioCtrlRegs.GPAMUX1.bit.GPIO12 = 1;

    // Gpio13 - ePWM7B
    GpioCtrlRegs.GPAGMUX1.bit.GPIO13 = 0;
    GpioCtrlRegs.GPAMUX1.bit.GPIO13 = 1;

    // Gpio14 - ePWM8A
    GpioCtrlRegs.GPAGMUX1.bit.GPIO14 = 0;
    GpioCtrlRegs.GPAMUX1.bit.GPIO14 = 1;

    // Gpio15 - ePWM8B
    GpioCtrlRegs.GPAGMUX1.bit.GPIO15 = 0;
    GpioCtrlRegs.GPAMUX1.bit.GPIO15 = 1;

    // Gpio25 - GPIO
    GpioCtrlRegs.GPAGMUX2.bit.GPIO25 = 0;
    GpioCtrlRegs.GPAMUX2.bit.GPIO25 = 0;

    // Gpio41 - GPIO
    GpioCtrlRegs.GPBGMUX1.bit.GPIO41 = 0;
    GpioCtrlRegs.GPBMUX1.bit.GPIO41 = 0;

    // Gpio42 - I2CA_SDA
    GpioCtrlRegs.GPBGMUX1.bit.GPIO42 = 1;
    GpioCtrlRegs.GPBMUX1.bit.GPIO42 = 2;

    // Gpio43 - I2CA_SCL
    GpioCtrlRegs.GPBGMUX1.bit.GPIO43 = 1;
    GpioCtrlRegs.GPBMUX1.bit.GPIO43 = 2;

    // Gpio47 - GPIO
    GpioCtrlRegs.GPBGMUX1.bit.GPIO47 = 0;
    GpioCtrlRegs.GPBMUX1.bit.GPIO47 = 0;

    // Gpio58 - CANA_RX
    GpioCtrlRegs.GPBGMUX2.bit.GPIO58 = 2;
    GpioCtrlRegs.GPBMUX2.bit.GPIO58 = 3;

    // Gpio59 - CANA_TX
    GpioCtrlRegs.GPBGMUX2.bit.GPIO59 = 2;
    GpioCtrlRegs.GPBMUX2.bit.GPIO59 = 3;

    // Gpio60 - GPIO
    GpioCtrlRegs.GPBGMUX2.bit.GPIO60 = 0;
    GpioCtrlRegs.GPBMUX2.bit.GPIO60 = 0;

    // Gpio61 - GPIO
    GpioCtrlRegs.GPBGMUX2.bit.GPIO61 = 0;
    GpioCtrlRegs.GPBMUX2.bit.GPIO61 = 0;

    // Gpio62 - EQEP3_A
    GpioCtrlRegs.GPBGMUX2.bit.GPIO62 = 1;
    GpioCtrlRegs.GPBMUX2.bit.GPIO62 = 1;

    // Gpio63 - EQEP3_B
    GpioCtrlRegs.GPBGMUX2.bit.GPIO63 = 1;
    GpioCtrlRegs.GPBMUX2.bit.GPIO63 = 1;

    // Gpio64 - EQEP3_STROBE
    GpioCtrlRegs.GPCGMUX1.bit.GPIO64 = 1;
    GpioCtrlRegs.GPCMUX1.bit.GPIO64 = 1;

    // Gpio65 - EQEP3_INDEX
    GpioCtrlRegs.GPCGMUX1.bit.GPIO65 = 1;
    GpioCtrlRegs.GPCMUX1.bit.GPIO65 = 1;

    // Gpio66 - GPIO
    GpioCtrlRegs.GPCGMUX1.bit.GPIO66 = 0;
    GpioCtrlRegs.GPCMUX1.bit.GPIO66 = 0;

    // Gpio69 - GPIO
    GpioCtrlRegs.GPCGMUX1.bit.GPIO69 = 0;
    GpioCtrlRegs.GPCMUX1.bit.GPIO69 = 0;

    // Gpio70 - SCIB_TX
    GpioCtrlRegs.GPCGMUX1.bit.GPIO70 = 1;
    GpioCtrlRegs.GPCMUX1.bit.GPIO70 = 2;

    // Gpio71 - SCIB_RX
    GpioCtrlRegs.GPCGMUX1.bit.GPIO71 = 1;
    GpioCtrlRegs.GPCMUX1.bit.GPIO71 = 2;

    // Gpio73 - GPIO
    GpioCtrlRegs.GPCGMUX1.bit.GPIO73 = 0;
    GpioCtrlRegs.GPCMUX1.bit.GPIO73 = 0;

    // Gpio78 - GPIO
    GpioCtrlRegs.GPCGMUX1.bit.GPIO78 = 0;
    GpioCtrlRegs.GPCMUX1.bit.GPIO78 = 0;

    // Gpio80 - GPIO
    GpioCtrlRegs.GPCGMUX2.bit.GPIO80 = 0;
    GpioCtrlRegs.GPCMUX2.bit.GPIO80 = 0;

    // Gpio85 - ePWM13A
    GpioCtrlRegs.GPCGMUX2.bit.GPIO85 = 0;
    GpioCtrlRegs.GPCMUX2.bit.GPIO85 = 1;

    // Gpio90 - GPIO
    GpioCtrlRegs.GPCGMUX2.bit.GPIO90 = 0;
    GpioCtrlRegs.GPCMUX2.bit.GPIO90 = 0;

    // Gpio91 - I2CA_SDA
    GpioCtrlRegs.GPCGMUX2.bit.GPIO91 = 1;
    GpioCtrlRegs.GPCMUX2.bit.GPIO91 = 2;

    // Gpio92 - I2CA_SCL
    GpioCtrlRegs.GPCGMUX2.bit.GPIO92 = 1;
    GpioCtrlRegs.GPCMUX2.bit.GPIO92 = 2;

    // Gpio200 - STS LED
    GpioCtrlRegs.GPGAMSEL.bit.GPIO200 = 0;  // digital pin
    GpioCtrlRegs.GPGGMUX1.bit.GPIO200 = 0;
    GpioCtrlRegs.GPGMUX1.bit.GPIO200 = 0;
    GpioCtrlRegs.GPGDIR.bit.GPIO200 = 1;    // output


    // --- Analog / Digital pins ----------------------------------------------------------------------------------------------------------
    // Gpio203 - ADC IN C6
    GpioCtrlRegs.GPGAMSEL.bit.GPIO203 = 1;          // The analog function of the pin is enabled and the pin is capable of analog functions
    AnalogSubsysRegs.AGPIOCTRLG.bit.GPIO203 = 1;    // AGPIO functionality is enabled

    // Gpio204 - ADC IN C5
    GpioCtrlRegs.GPGAMSEL.bit.GPIO204 = 1;          // The analog function of the pin is enabled and the pin is capable of analog functions
    AnalogSubsysRegs.AGPIOCTRLG.bit.GPIO204 = 1;    // AGPIO functionality is enabled

    // Gpio205 - ADC IN C4
    GpioCtrlRegs.GPGAMSEL.bit.GPIO205 = 1;          // The analog function of the pin is enabled and the pin is capable of analog functions
    AnalogSubsysRegs.AGPIOCTRLG.bit.GPIO205 = 1;    // AGPIO functionality is enabled

    // Gpio207 - ADC IN B6
    GpioCtrlRegs.GPGAMSEL.bit.GPIO207 = 1;          // The analog function of the pin is enabled and the pin is capable of analog functions
    AnalogSubsysRegs.AGPIOCTRLG.bit.GPIO207 = 1;    // AGPIO functionality is enabled

    // Gpio208 - ADC IN B7
    GpioCtrlRegs.GPGAMSEL.bit.GPIO208 = 1;          // The analog function of the pin is enabled and the pin is capable of analog functions
    AnalogSubsysRegs.AGPIOCTRLG.bit.GPIO208 = 1;    // AGPIO functionality is enabled

    // Gpio209 - ADC IN A6
    GpioCtrlRegs.GPGAMSEL.bit.GPIO209 = 1;          // The analog function of the pin is enabled and the pin is capable of analog functions
    AnalogSubsysRegs.AGPIOCTRLG.bit.GPIO209 = 1;    // AGPIO functionality is enabled

    // Gpio213 - ADC IN A10
    GpioCtrlRegs.GPGAMSEL.bit.GPIO213 = 1;          // The analog function of the pin is enabled and the pin is capable of analog functions
    AnalogSubsysRegs.AGPIOCTRLG.bit.GPIO213 = 1;    // AGPIO functionality is enabled

    // Gpio214 - ADC IN A11
    GpioCtrlRegs.GPGAMSEL.bit.GPIO214 = 1;          // The analog function of the pin is enabled and the pin is capable of analog functions
    AnalogSubsysRegs.AGPIOCTRLG.bit.GPIO214 = 1;    // AGPIO functionality is enabled

    // AIO225 - ADC IN A14/B14/C14
    GpioCtrlRegs.GPHAMSEL.bit.GPIO225 = 1;          // The analog function of the pin is enabled

    // AIO226 - ADC IN A15/B15/C15
    GpioCtrlRegs.GPHAMSEL.bit.GPIO226 = 1;          // The analog function of the pin is enabled

    // AIO227 - ADC IN A0/A12/B12/C12/DACA OUT
    GpioCtrlRegs.GPHAMSEL.bit.GPIO227 = 1;          // The analog function of the pin is enabled

    // AIO228 - ADC IN A1/B19
    GpioCtrlRegs.GPHAMSEL.bit.GPIO228 = 1;          // The analog function of the pin is enabled

    // AIO229 - ADC IN A2/B20
    GpioCtrlRegs.GPHAMSEL.bit.GPIO229 = 1;          // The analog function of the pin is enabled

    // AIO230 - ADC IN A3
    GpioCtrlRegs.GPHAMSEL.bit.GPIO230 = 1;          // The analog function of the pin is enabled

    // AIO234 - ADC IN B1/DACC OUT
    GpioCtrlRegs.GPHAMSEL.bit.GPIO234 = 1;          // The analog function of the pin is enabled

    EDIS;
}

