################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
CMD_SRCS += \
../28p65x_generic_ram_lnk_cpu1.cmd \
../f28p65x_headers_nonBIOS_cpu1.cmd 

ASM_SRCS += \
../f28p65x_codestartbranch.asm \
../f28p65x_usdelay.asm 

C_SRCS += \
../CpuTimer.c \
../Gpio.c \
../f28p65x_adc.c \
../f28p65x_globalvariabledefs.c \
../f28p65x_piectrl.c \
../f28p65x_sysctrl.c \
../main.c 

C_DEPS += \
./CpuTimer.d \
./Gpio.d \
./f28p65x_adc.d \
./f28p65x_globalvariabledefs.d \
./f28p65x_piectrl.d \
./f28p65x_sysctrl.d \
./main.d 

OBJS += \
./CpuTimer.obj \
./Gpio.obj \
./f28p65x_adc.obj \
./f28p65x_codestartbranch.obj \
./f28p65x_globalvariabledefs.obj \
./f28p65x_piectrl.obj \
./f28p65x_sysctrl.obj \
./f28p65x_usdelay.obj \
./main.obj 

ASM_DEPS += \
./f28p65x_codestartbranch.d \
./f28p65x_usdelay.d 

OBJS__QUOTED += \
"CpuTimer.obj" \
"Gpio.obj" \
"f28p65x_adc.obj" \
"f28p65x_codestartbranch.obj" \
"f28p65x_globalvariabledefs.obj" \
"f28p65x_piectrl.obj" \
"f28p65x_sysctrl.obj" \
"f28p65x_usdelay.obj" \
"main.obj" 

C_DEPS__QUOTED += \
"CpuTimer.d" \
"Gpio.d" \
"f28p65x_adc.d" \
"f28p65x_globalvariabledefs.d" \
"f28p65x_piectrl.d" \
"f28p65x_sysctrl.d" \
"main.d" 

ASM_DEPS__QUOTED += \
"f28p65x_codestartbranch.d" \
"f28p65x_usdelay.d" 

C_SRCS__QUOTED += \
"../CpuTimer.c" \
"../Gpio.c" \
"../f28p65x_adc.c" \
"../f28p65x_globalvariabledefs.c" \
"../f28p65x_piectrl.c" \
"../f28p65x_sysctrl.c" \
"../main.c" 

ASM_SRCS__QUOTED += \
"../f28p65x_codestartbranch.asm" \
"../f28p65x_usdelay.asm" 


